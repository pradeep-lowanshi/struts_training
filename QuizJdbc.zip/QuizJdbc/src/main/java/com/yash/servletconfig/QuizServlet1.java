package com.yash.servletconfig;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/QuizServlet1")
public class QuizServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public QuizServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String paramName, paramValue[] ;
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		int cnt=0;
		String ans="";
		
		Enumeration paramNames = request.getParameterNames();
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/struts","root","root");
			stmt = con.createStatement();
			rs=stmt.executeQuery("select ans from quiz");
			
			while(rs.next() && paramNames.hasMoreElements())
			{
				String un=rs.getString(1);
				paramName = (String)paramNames.nextElement();
				paramValue=request.getParameterValues(paramName);
				for(int i=0;i<paramValue.length;i++)
				{
					ans=paramValue[0];
				}
				
				if(un.equals(ans))
					cnt++;
			}
			out.println("<h1>You have scored "+cnt+" Points out of 3.</h1>");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			out.println("Sorry, Ty again later!");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
