package com.pradeep.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/TableServlet")
public class TableServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public TableServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
       /* PrintWriter out = response.getWriter();
        Request parameter code
        String name = request.getParameter("n1");
        String password = request.getParameter("p1");
        out.write("Your name is: "+name+"and password is :"+password);*/

		/*CODE TO GET TABLE*/
		
		int num= Integer.parseInt(request.getParameter("num"));
		PrintWriter out=response.getWriter();
		out.write("<table border='1'>");
		for(int i=1;i<=10;i++) {
			String color=i%2==0?"grey":"white";
			out.write("<tr style='background-color:"+color+"'>");
			out.write("<td>"+num+"</td>");
			out.write("<td>*</td>");
			out.write("<td>"+i+"</td>");
			out.write("<td>=</td>");
			out.write("<td>"+num*i+"</td>");
			
		}
		out.write("</table");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
