package com.pradeep.servlet.employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradeep.dao.EmployeeDaoImpl;
import com.pradeep.model.Employee;

/**
 * Servlet implementation class EmployeeDisplay
 */
@WebServlet("/EmployeeDisplay")
public class EmployeeDisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDisplay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			List<Employee> employee = new EmployeeDaoImpl().getAllEmployee();
			out.println("<table>");
			out.print("<thead><th>ED</th><th>ENAME</th><th>Designation</th></thead>");
			out.print("<tbody>");
			for(Employee employees:employee) {
				out.print("<td><td>"+employees.getEmpid()+"</td><td>"+employees.getEname()+"</td><td>"+employees.getDesignation()+"</td></tr>");
			}
			out.print("</tbody>");
			out.print("</table>");
		}
		catch(SQLException ex) {
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
