package com.pradeep.servlet.employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pradeep.dao.DepartmentDaoImpl;
import com.pradeep.dao.EmployeeDaoImpl;
import com.pradeep.model.Department;
import com.pradeep.model.Employee;

/**
 * Servlet implementation class EmployeeBydepartment
 */
@WebServlet("/EmployeeBydepartment")
public class EmployeeBydepartment extends HttpServlet {
	  private static final long serialVersionUID = 1L;



	   public EmployeeBydepartment() {
	        super();
	        // TODO Auto-generated constructor stub
	    }



	   public static String getEmployeeRow(Employee e1) {
	        return "<tr><td>" + e1.getEname() + "</td><td>" + e1.getDeptid() + "</td><td>" + e1.getSalary() + "</td></tr>";
	    }



	   protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        try {
	            List<Department> departments = new DepartmentDaoImpl().getAllDepartment();
	            String dname = request.getParameter("s1") == null ? "sales" : request.getParameter("s1");
	            out.write("<form>");
	            out.write("<select name='s1'   onchange='form.submit()'>");
	            departments.stream().forEach(department -> {
	                if (department.getDeptName().equals(dname))
	                    out.write("<option selected>" + department.getDeptName() + "</option>");
	                else
	                    out.write("<option>" + department.getDeptName() + "</option>");



	           });
	            out.write("</select>");
	            out.write("</form>");



	           List<Employee> employees = new EmployeeDaoImpl().getAllemployeeByDepartment(dname);
	            out.write("<table>");
	            employees.stream().forEach(employee -> {
	                out.write(EmployeeBydepartment.getEmployeeRow(employee));
	            });
	            out.write("</table>");



	       } catch (SQLException ex) {
	        }
	    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
