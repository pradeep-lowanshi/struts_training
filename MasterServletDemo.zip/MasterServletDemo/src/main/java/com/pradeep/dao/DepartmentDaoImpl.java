package com.pradeep.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import com.pradeep.model.Department;

public class DepartmentDaoImpl implements DepartmentDao {

	   @Override
	    public void AddDepartment(Department department) {
	        try {
	            Connection c=ConnectionMaster.getConnection();
	            PreparedStatement ps=c.prepareStatement("insert into department values (?,?,?)");
	            ps.setInt(1, department.getId());
	            ps.setString(2, department.getDeptName());
	            ps.setString(3, department.getCity());
	            ps.executeUpdate();
	        }catch(Exception e)
	        {
	            System.out.println(e);
	        }
	        
	    }



	   @Override
	    public List<Department> getAllDepartment() {
	        // TODO Auto-generated method stub
	        List<Department>departments=null;
	        try
	        {
	            Connection c=ConnectionMaster.getConnection();
	            PreparedStatement ps=c.prepareStatement("select * from department");
	            ResultSet rs=ps.executeQuery();
	            departments=new LinkedList<Department>();
	            while(rs.next())
	            {
	                departments.add(new Department( rs.getInt("deptid"), rs.getString("dname")));
	            }
	        }catch(Exception e)
	        {
	            System.out.println(e);
	        }
	        return departments;
	    }



	   @Override
	    public Department getById(int id) {
	        Department dept=null;
	        try
	        {
	            Connection c=ConnectionMaster.getConnection();
	            
	            PreparedStatement ps=c.prepareStatement("select * from department where deptid=?");
	            ps.setInt(1, id);
	            ResultSet rs=ps.executeQuery();
	            if(rs.next())
	            {
	                dept=new Department(rs.getInt("deptid"),rs.getString("dname"));
	            }
	        }catch(Exception e)
	        {
	            System.out.println(e);
	        }
	        return dept;
	    }



	   @Override
	    public void updateDepartment(Department dept) {
	        try
	        {
	            Connection c=ConnectionMaster.getConnection();
	            PreparedStatement ps=c.prepareStatement("update department set city=?,dname=? where deptid=?");
	            ps.setString(1, dept.getCity());
	            ps.setString(2, dept.getDeptName());
	            ps.setInt(3, dept.getId());
	            ps.executeUpdate();
	        }catch(Exception e)
	        {
	            System.out.println(e);
	        }
	        
	    }



}
