package com.pradeep.dao;

import java.sql.SQLException;
import java.util.List;

import com.pradeep.model.Department;

public interface DepartmentDao {

	void AddDepartment(Department department);

	List<Department> getAllDepartment()throws SQLException;

	Department getById(int id)throws SQLException;

	void updateDepartment(Department dept)throws SQLException;

}
