package com.pradeep.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionMaster {

	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/struts", "root", "root");

		} catch (SQLException ex) {
			System.out.print(ex.getMessage());
		} catch (ClassNotFoundException ex) {
			System.out.print(ex.getMessage());
		}
		return conn;
	}

}
