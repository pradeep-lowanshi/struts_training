package com.pradeep.form;

public class Employee {
private int empid;
private String ename;
private int deptid;
private int salary;
private String designation;
private int mgrid;
private String password;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getDeptid() {
	return deptid;
}
public void setDeptid(int deptid) {
	this.deptid = deptid;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public int getMgrid() {
	return mgrid;
}
public void setMgrid(int mgrid) {
	this.mgrid = mgrid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Employee(int empid, String ename, int deptid, int salary, String designation, int mgrid, String password) {
	super();
	this.empid = empid;
	this.ename = ename;
	this.deptid = deptid;
	this.salary = salary;
	this.designation = designation;
	this.mgrid = mgrid;
	this.password = password;
}
public Employee() {
	// TODO Auto-generated constructor stub
}

}
