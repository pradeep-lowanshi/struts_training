package com.pradeep.form;

import org.apache.struts.action.ActionForm;

public class DispatchForm extends ActionForm{
private String mcall;

public String getMcall() {
	return mcall;
}

public void setMcall(String mcall) {
	this.mcall = mcall;
}

}
