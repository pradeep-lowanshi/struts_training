package com.pradeep.form;

import org.apache.struts.action.ActionForm;

public class UserUpdateOrDelete extends ActionForm{
	private int id;
	private String name;
	private int deptid;
	private int salary;
	private String designation;
	private int mgrid;
	

	public UserUpdateOrDelete(int id, String name, int deptid, int salary, String designation, int mgrid) {
		super();
		this.id = id;
		this.name = name;
		this.deptid = deptid;
		this.salary = salary;
		this.designation = designation;
		this.mgrid = mgrid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getMgrid() {
		return mgrid;
	}

	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public UserUpdateOrDelete() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserUpdateOrDelete(int id) {
		super();
		this.id = id;
	}
	

}
