package com.pradeep.action;

import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.pradeep.exception.EmailNotValidException;
import com.pradeep.form.MyEmployee;

public class MyEmployeeAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		MyEmployee  employee = (MyEmployee)form;
		String regex = "^(.+)@(.+)$";
		 
		Pattern pattern = Pattern.compile(regex);
		if(!pattern.matcher(employee.getEmail()).matches())
			throw new EmailNotValidException("The email is not valid");
		request.setAttribute("employee", employee);
		return mapping.findForward("success");
	}

}
