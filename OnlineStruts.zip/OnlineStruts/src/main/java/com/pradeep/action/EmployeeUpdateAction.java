package com.pradeep.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.pradeep.dao.EmployeeDaoImpl;
import com.pradeep.form.UserUpdateOrDelete;

public class EmployeeUpdateAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		UserUpdateOrDelete u1 = (UserUpdateOrDelete) form;
		
		new EmployeeDaoImpl().updateEmployee(u1.getId(),u1.getName(),u1.getDeptid(),u1.getSalary(),u1.getDesignation(),u1.getMgrid());
		
		request.setAttribute("employee",new EmployeeDaoImpl().getEmployeeById(u1.getId()));
		return mapping.findForward("success");
	}

}
