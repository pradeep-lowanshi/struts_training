package com.pradeep.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.actions.LookupDispatchAction;

//public class MyDispatchAction extends DispatchAction { this for Dispatch Action
public class MyDispatchAction extends LookupDispatchAction {// This is for LookupDispatchAction
	
//	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request,
//			HttpServletResponse response) throws Exception {
//		// TODO Auto-generated method stub
//		request.setAttribute("message", "add button has been clicked");
//		return mapping.findForward("success");
//	}
//	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request,
//			HttpServletResponse response) throws Exception {
//		// TODO Auto-generated method stub
//		request.setAttribute("message", "update button has been clicked");
//		return mapping.findForward("success");
//	}
//	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request,
//			HttpServletResponse response) throws Exception {
//		// TODO Auto-generated method stub
//		request.setAttribute("message", "delete button has been clicked");
//		return mapping.findForward("success");
//	}
	
	public ActionForward addCall(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setAttribute("message", "add button has been clicked");
		return mapping.findForward("success");
	}
	public ActionForward updateCall(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setAttribute("message", "update button has been clicked");
		return mapping.findForward("success");
	}
	public ActionForward deleteCall(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setAttribute("message", "delete button has been clicked");
		return mapping.findForward("success");
	}
	@Override
	protected Map getKeyMethodMap() {
		// TODO Auto-generated method stub
		Map<String,String> m1 = new HashMap<String,String>();
		m1.put("dispatch.form.add","addCall");
		m1.put("dispatch.form.update","updateCall");
		m1.put("dispatch.form.delete","deleteCall");
		return m1;
	}


}
