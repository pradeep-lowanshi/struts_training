package com.pradeep.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.pradeep.dao.EmployeeDaoImpl;
import com.pradeep.form.User;

public class UserAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		User user = (User)form;
		if(user.getFirstname().equals("Pradeep")&&user.getLastname().equals("Lowanshi")) {
			request.setAttribute("employees",new EmployeeDaoImpl().getAllEmployee());
			return mapping.findForward("success");	
		}
		else {
			request.setAttribute("message","Login failed");
			return mapping.findForward("failure");
		}
		
	}

}
