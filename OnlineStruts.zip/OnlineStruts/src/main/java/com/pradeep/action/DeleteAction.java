package com.pradeep.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.pradeep.dao.EmployeeDaoImpl;
import com.pradeep.form.UserUpdateOrDelete;

public class DeleteAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		UserUpdateOrDelete u1 = (UserUpdateOrDelete) form;
		new EmployeeDaoImpl().deleteEmployee(u1.getId());
		request.setAttribute("employee",new EmployeeDaoImpl().getAllEmployee());
		
		return mapping.findForward("success");
	}
	

}
