package com.pradeep.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pradeep.form.Employee;



public class EmployeeDaoImpl implements EmployeeDao {
@Override
public List<Employee> getAllEmployee() throws SQLException {
	// TODO Auto-generated method stub
	List<Employee> employees = new ArrayList<Employee>();
	Connection conn = ConnectionMaster.getConnection();
	Statement st = conn.createStatement();
	ResultSet rs = st.executeQuery("select * from Employee");
	while(rs.next()) {
		employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7)));
	}
	return employees;
}

@Override
public void addEmployee(Employee employee) throws SQLException {
	// TODO Auto-generated method stub
	Connection conn = ConnectionMaster.getConnection();
	PreparedStatement ps = conn.prepareStatement("insert into Employee(eid,ename,deptid,salary,designation,mgrid,password) values(?,?,?,?,?,?,?)");
	ps.setInt(1,employee.getEmpid());
	ps.setString(2, employee.getEname());
	ps.setInt(3, employee.getDeptid());
	ps.setInt(4,employee.getSalary());
	ps.setString(5, employee.getDesignation());
	ps.setInt(6,employee.getMgrid());
	ps.setString(7, employee.getPassword());
	ps.executeUpdate();
	  
	
}

@Override
public Employee getEmployeeById(int id) throws SQLException {
	// TODO Auto-generated method stub
	Connection conn = ConnectionMaster.getConnection();
	Employee e1 = null;
	PreparedStatement ps = 	conn.prepareStatement("select * from Employee where empid=?");
	ps.setInt(1,id);
	ResultSet rs = ps.executeQuery();
	if(rs.next()) {
		e1=new Employee (rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7));
	}
	return e1;
}

@Override
public void deleteEmployee(int eid) throws SQLException {
	// TODO Auto-generated method stub
	Connection conn = ConnectionMaster.getConnection();
	PreparedStatement ps = conn.prepareStatement("delete from Employee where empid=?");
	ps.setInt(1,eid);
	ps.executeUpdate();
	
}

@Override
public List<Employee> getAllemployeeByDepartment(String department) throws SQLException {
	// TODO Auto-generated method stub
	Connection conn = ConnectionMaster.getConnection();
	List<Employee> employees = new ArrayList<Employee>();
	PreparedStatement ps = conn.prepareStatement("select * from employee where deptid=(select deptid from department where dname = ?)");
	ps.setString(1, department);
	ResultSet rs = ps.executeQuery();
	while(rs.next()) {
		employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7)));
	}
	return employees;
}

@Override
public void updateEmployee(int id,String name,int deptid,int salary,String designation,int mgrid) throws SQLException {
	// TODO Auto-generated method stub
	Connection conn = ConnectionMaster.getConnection();
	System.out.println(name);
	PreparedStatement ps = conn.prepareStatement("update employee set ename=?,deptid=?,salary=?,designation=?,mgrid=? where empid=?");
	Employee employee = new Employee();
//	ps.setString(1, employee.getEname());
//    ps.setInt(2, employee.getDeptid());
//    ps.setInt(3, employee.getSalary());
//    ps.setString(4, employee.getDesignation());
//    ps.setInt(5, employee.getMgrid());
//   ps.setInt(6, employee.getEmpid());
	ps.setString(1, name);
    ps.setInt(2, deptid);
    ps.setInt(3, salary);
    ps.setString(4, designation);
    ps.setInt(5, mgrid);
   ps.setInt(6, id);
    ps.executeUpdate();
	
	
}


}
