package com.pradeep.exception;

public class EmailNotValidException extends RuntimeException {
private String message;

public EmailNotValidException(String message) {
	super();
	this.message = message;
}

public EmailNotValidException() {
	super();
	// TODO Auto-generated constructor stub
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

}
